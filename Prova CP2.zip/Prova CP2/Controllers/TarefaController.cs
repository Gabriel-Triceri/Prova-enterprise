using API_Aula_2.Data;
using API_Aula_2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace API_Aula_2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TarefaController : ControllerBase
    {
        private readonly DataContext _context;

        public TarefaController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IEnumerable<Tarefa> GetAll()
        {
            return _context.Tarefa.ToList();
        }

        [HttpPost]
        public ActionResult<Tarefa> Add(Tarefa tarefa)
        {
            _context.Tarefa.Add(tarefa);
            _context.SaveChanges();
            return Ok(tarefa);
        }

        [HttpPut]
        public ActionResult Update(Tarefa tarefa)
        {
            _context.Entry(tarefa).State = EntityState.Modified;
            _context.SaveChanges();
            return Ok();
        }

        [HttpDelete]
        public ActionResult Delete(int id)
        {
            var tarefa = _context.Tarefa.Find(id);
            if (tarefa == null)
            {
                return NotFound();
            }

            _context.Tarefa.Remove(tarefa);
            _context.SaveChanges();
            return Ok();
        }

        [HttpGet("{id}")]
        public ActionResult<Tarefa> GetById(int id)
        {
            var tarefa = _context.Tarefa.Find(id);
            if (tarefa == null)
            {
                return NotFound();
            }

            return Ok(tarefa);
        }
    }
}
