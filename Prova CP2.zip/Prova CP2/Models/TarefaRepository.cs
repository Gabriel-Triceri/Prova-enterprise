﻿namespace API_Aula_2.Models
{
    public interface TarefaRepository
    {
        Tarefa GetById(int id);
        IEnumerable<Tarefa> GetAll();
        void Add(Tarefa entity);
        void Update(Tarefa entity);
        void Delete(Tarefa id);
    }
}
