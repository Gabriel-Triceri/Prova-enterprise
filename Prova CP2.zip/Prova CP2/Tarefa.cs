using System.ComponentModel.DataAnnotations;

namespace API_Aula_2.Models
{
    public class Tarefa
    {
        [Key]
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public string AssignedTo { get; set; }
        public string Status { get; set; }
    }
}